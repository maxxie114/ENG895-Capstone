# install.packages("ggplot2")
# install.packages("crayon")
# install.packages("ggpubr")
# install.packages("wesanderson") # https://github.com/karthik/wesanderson

library(ggplot2)
library(crayon)
library(RColorBrewer)
library(ggpubr)
library(wesanderson)



### RECURSION

recursion_gpt_3_5_turbo_0125<-read.csv(
  "_2_recursion_combined - gpt-3.5-turbo-0125.csv")
recursion_gpt_3_5_turbo_0125<-recursion_gpt_3_5_turbo_0125[-31,]
recursion_gpt_3_5_turbo_0125$model<-"gpt-3.5"

recursion_gpt_4_0314<-read.csv(
  "_2_recursion_combined - gpt-4-0314.csv")
recursion_gpt_4_0314<-recursion_gpt_4_0314[-31,]
recursion_gpt_4_0314$model<-"gpt-4"

recursion_meta_llama3_1_405b_instruct_v1<-read.csv(
  "_2_recursion_combined - meta.llama3-1-405b-instruct-v1.csv")
recursion_meta_llama3_1_405b_instruct_v1<-recursion_meta_llama3_1_405b_instruct_v1[-31,]
recursion_meta_llama3_1_405b_instruct_v1$model<-"llama3-1"

recursion_o1_preview_2024_09_12<-read.csv(
  "_2_recursion_combined - o1-preview-2024-09-12.csv")
recursion_o1_preview_2024_09_12<-recursion_o1_preview_2024_09_12[-31,]
recursion_o1_preview_2024_09_12$model<-"o1-preview"

recursion<-rbind(recursion_gpt_3_5_turbo_0125,
                 recursion_gpt_4_0314,
                 recursion_meta_llama3_1_405b_instruct_v1,
                 recursion_o1_preview_2024_09_12)

recursionIdentify<-ggplot(recursion, aes(x = model, y =  ident.MAJ, fill=model)) +
  stat_summary(fun = mean, geom = "bar", width = 0.5) +
  ylab("score") +
  ggtitle("Recursion Identify") +
  theme_minimal() 
recursionIdentify

recursionTrees<-ggplot(recursion, aes(x = model, y =  tree.MAJ, fill=model)) +
  stat_summary(fun = mean, geom = "bar", width = 0.5) +
  ylab("score") +
  ggtitle("Recursion Trees") +
  theme_minimal() 
recursionTrees

recursionType<-ggplot(recursion, aes(x = model, y =  type.MAJ, fill=model)) +
  stat_summary(fun = mean, geom = "bar", width = 0.5) +
  ylab("score") +
  ggtitle("Recursion Type") +
  theme_minimal() 
recursionType

recursionAdd<-ggplot(recursion, aes(x = model, y =  add.MAJ, fill=model)) +
  stat_summary(fun = mean, geom = "bar", width = 0.5) +
  ylab("score") +
  ggtitle("Recursion Add") +
  theme_minimal() 
recursionAdd

ggarrange(recursionIdentify,recursionType,recursionTrees,recursionAdd)

recursionIdentAll<- data.frame(Score=recursion$ident.MAJ,model=recursion$model)
recursionIdentAll$Task<-"identify"

recursionTypeAll<- data.frame(Score=recursion$type.MAJ,model=recursion$model)
recursionTypeAll$Task<-"type"

recursionTreeAll<- data.frame(Score=recursion$tree.MAJ,model=recursion$model)
recursionTreeAll$Task<-"tree"

recursionAddAll<- data.frame(Score=recursion$add.MAJ,model=recursion$model)
recursionAddAll$Task<-"add"

recursionAll<-rbind(recursionIdentAll,recursionTypeAll,recursionTreeAll,recursionAddAll)
recursionAll$Task<-factor(recursionAll$Task,levels=c("identify","type","tree","add"))

colors <- brewer.pal(9, "Purples")[c(3,5,7,9)]

recursionAllGG <- ggplot(recursionAll, aes(x = model, y = Score, fill = model)) +
  stat_summary(fun = mean, geom = "bar", width = 1,
               position = position_dodge(width = 0)) +
  ylab("score") +
  xlab(NULL) + # Remove the x-axis label
  ggtitle("recursion") +
  theme_minimal() +
  theme(
    strip.text = element_text(size = 13),
    axis.text.x = element_blank() # Remove labels under individual bars
  ) +
  ylim(0, 1) +
  facet_grid(~Task) +
  scale_fill_manual(values = colors)

recursionAllGG <- recursionAllGG+ theme(legend.position = "none")
recursionAllGG
ggsave("recursionAllGG.pdf", height=5, width=11)



### AMBIGUITY

ambiguity_gpt_3_5_turbo_0125<-read.csv(
  "_1_ambiguity_combined - gpt-3.5-turbo-0125.csv")
ambiguity_gpt_3_5_turbo_0125<-ambiguity_gpt_3_5_turbo_0125[-31,]
ambiguity_gpt_3_5_turbo_0125$model<-"gpt-3.5"

ambiguity_gpt_4_0314<-read.csv(
  "_1_ambiguity_combined - gpt-4-0314.csv")
ambiguity_gpt_4_0314<-ambiguity_gpt_4_0314[-31,]
ambiguity_gpt_4_0314$model<-"gpt-4"

ambiguity_meta_llama3_1_405b_instruct_v1<-read.csv(
  "_1_ambiguity_combined - meta.llama3-1-405b-instruct-v1.csv")
ambiguity_meta_llama3_1_405b_instruct_v1<-ambiguity_meta_llama3_1_405b_instruct_v1[-31,]
ambiguity_meta_llama3_1_405b_instruct_v1$model<-"llama3-1"

ambiguity_o1_preview_2024_09_12<-read.csv(
  "_1_ambiguity_combined - o1-preview-2024-09-12.csv")
ambiguity_o1_preview_2024_09_12<-ambiguity_o1_preview_2024_09_12[-31,]
ambiguity_o1_preview_2024_09_12$model<-"o1-preview"

ambiguity<-rbind(ambiguity_gpt_3_5_turbo_0125,
                 ambiguity_gpt_4_0314,
                 ambiguity_meta_llama3_1_405b_instruct_v1,
                 ambiguity_o1_preview_2024_09_12)

ambiguityIdentify<-ggplot(ambiguity, aes(x = model, y =  ident.MAJ)) +
  stat_summary(fun = mean, geom = "bar", width = 0.5) +
  ylab("score") +
  ggtitle("Ambiguity Identify") +
  theme_minimal() 
ambiguityIdentify

ambiguityTrees<-ggplot(ambiguity, aes(x = model, y =  trees.MAJ)) +
  stat_summary(fun = mean, geom = "bar", width = 0.5) +
  ylab("score") +
  ggtitle("Ambiguity Trees") +
  theme_minimal() 
ambiguityTrees

ambiguityIdentAll<- data.frame(Score=ambiguity$ident.MAJ,model=ambiguity$model)
ambiguityIdentAll$Task<-"identify"

ambiguityTreesAll<- data.frame(Score=ambiguity$trees.MAJ,model=ambiguity$model)
ambiguityTreesAll$Task<-"tree"

ambiguityAll<-rbind(ambiguityIdentAll,ambiguityTreesAll)

ambiguityAll$Task<-factor(ambiguityAll$Task,levels=c("identify","tree"))

colors <- brewer.pal(9, "Blues")[c(3,5,7,9)]

ambiguityAllGG <- ggplot(ambiguityAll, aes(x = model, y = Score, fill = model)) +
  stat_summary(fun = mean, geom = "bar", width = 1,
               position = position_dodge(width = 0)) +
  ylab("score") +
  xlab(NULL) + # Remove the x-axis label
  ggtitle("ambiguity") +
  theme_minimal() +
  theme(
    strip.text = element_text(size = 13),
    axis.text.x = element_blank() # Remove labels under individual bars
  ) +
  ylim(0, 1) +
  facet_grid(~Task) +
  scale_fill_manual(values = colors)

ambiguityAllGG <- ambiguityAllGG+ theme(legend.position = "none")
ambiguityAllGG
ggsave("ambiguityAllGG.pdf", height=3, width=3)



### MOVEMENT

movement_gpt_3_5_turbo_0125<-read.csv(
  "_3_movement_combined - gpt-3.5-turbo-0125.csv")
movement_gpt_3_5_turbo_0125<-movement_gpt_3_5_turbo_0125[-31,]
movement_gpt_3_5_turbo_0125$model<-"gpt-3.5"

movement_gpt_4_0314<-read.csv(
  "_3_movement_combined - gpt-4-0314.csv")
movement_gpt_4_0314<-movement_gpt_4_0314[-31,]
movement_gpt_4_0314$model<-"gpt-4"

movement_meta_llama3_1_405b_instruct_v1<-read.csv(
  "_3_movement_combined - meta.llama3-1-405b-instruct-v1.csv")
movement_meta_llama3_1_405b_instruct_v1<-movement_meta_llama3_1_405b_instruct_v1[-31,]
movement_meta_llama3_1_405b_instruct_v1$model<-"llama3-1"

movement_o1_preview_2024_09_12<-read.csv(
  "_3_movement_combined - o1-preview-2024-09-12.csv")
movement_o1_preview_2024_09_12<-movement_o1_preview_2024_09_12[-31,]
movement_o1_preview_2024_09_12$model<-"o1-preview"

movement<-rbind(movement_gpt_3_5_turbo_0125,
                movement_gpt_4_0314,
                movement_meta_llama3_1_405b_instruct_v1,
                movement_o1_preview_2024_09_12)

movementTreesAll<- data.frame(Score=movement$MAJ,model=movement$model)
movementTreesAll$Task<-"tree"

movementAll<-rbind(movementTreesAll)
movementAll$Task<-factor(movementAll$Task,levels=c("identify","tree"))

colors <- brewer.pal(9, "Reds")[c(3,5,7,9)]

movementAllGG <- ggplot(movementAll, aes(x = model, y = Score, fill = model)) +
  stat_summary(fun = mean, geom = "bar", width = 1,
               position = position_dodge(width = 0)) +
  ylab("score") +
  xlab(NULL) + # Remove the x-axis label
  ggtitle("movement") +
  theme_minimal() +
  theme(
    strip.text = element_text(size = 13),
    axis.text.x = element_blank() # Remove labels under individual bars
  ) +
  ylim(0, 1) +
  facet_grid(~Task) +
  scale_fill_manual(values = colors)

# movementAllGG <- movementAllGG+ theme(legend.position = "none")
movementAllGG
ggsave("movementAllGG.pdf", height=3, width=1.85)



### PHONOLOGY

phonology_gpt_3_5_turbo_0125 <- read.csv(
  "_4_phonology_combined - gpt-3.5-turbo-0125.csv")
phonology_gpt_3_5_turbo_0125 <- phonology_gpt_3_5_turbo_0125[-31,]
phonology_gpt_3_5_turbo_0125$model <- "gpt-3.5"

phonology_gpt_4_0314 <- read.csv(
  "_4_phonology_combined - gpt-4-0314.csv")
phonology_gpt_4_0314 <- phonology_gpt_4_0314[-31,]
phonology_gpt_4_0314$model <- "gpt-4"

phonology_meta_llama3_1_405b_instruct_v1 <- read.csv(
  "_4_phonology_combined - meta.llama3-1-405b-instruct-v1.csv")
phonology_meta_llama3_1_405b_instruct_v1 <- phonology_meta_llama3_1_405b_instruct_v1[-31,]
phonology_meta_llama3_1_405b_instruct_v1$model <- "llama3-1"

phonology_o1_preview_2024_09_12 <- read.csv(
  "_4_phonology_combined - o1-preview-2024-09-12.csv")
phonology_o1_preview_2024_09_12 <- phonology_o1_preview_2024_09_12[-31,]
phonology_o1_preview_2024_09_12$model <- "o1-preview"

phonology <- rbind(phonology_gpt_3_5_turbo_0125,
                 phonology_gpt_4_0314,
                 phonology_meta_llama3_1_405b_instruct_v1,
                 phonology_o1_preview_2024_09_12)

phonologyInput <- ggplot(phonology, aes(x = model, y =  input.MAJ, fill=model)) +
  stat_summary(fun = mean, geom = "bar", width = 0.5) +
  ylab("score") +
  ggtitle("Phonology Input") +
  theme_minimal() 
phonologyInput

phonologyOutput <- ggplot(phonology, aes(x = model, y =  output.MAJ, fill=model)) +
  stat_summary(fun = mean, geom = "bar", width = 0.5) +
  ylab("score") +
  ggtitle("Phonology Output") +
  theme_minimal() 
phonologyOutput

phonologyEnviron <- ggplot(phonology, aes(x = model, y =  environ.MAJ, fill=model)) +
  stat_summary(fun = mean, geom = "bar", width = 0.5) +
  ylab("score") +
  ggtitle("Phonology Environment") +
  theme_minimal() 
phonologyEnviron

ggarrange(phonologyInput, phonologyOutput, phonologyEnviron)

phonologyInputAll <- data.frame(Score=phonology$input.MAJ,model=phonology$model)
phonologyInputAll$Task <- "input"

phonologyOutputAll <- data.frame(Score=phonology$output.MAJ,model=phonology$model)
phonologyOutputAll$Task <- "output"

phonologyEnvironAll <- data.frame(Score=phonology$environ.MAJ,model=phonology$model)
phonologyEnvironAll$Task <- "environ"

phonologyAll <- rbind(phonologyInputAll, phonologyOutputAll, phonologyEnvironAll)
phonologyAll$Task <- factor(phonologyAll$Task, levels=c("input", "output", "environ"))

colors <- brewer.pal(9, "Greens")[c(3,5,7,9)]

phonologyAllGG <- ggplot(phonologyAll, aes(x = model, y = Score, fill = model)) +
  stat_summary(fun = mean, geom = "bar", width = 1,
               position = position_dodge(width = 0)) +
  ylab("score") +
  xlab(NULL) + # Remove the x-axis label
  ggtitle("phonology") +
  theme_minimal() +
  theme(
    strip.text = element_text(size = 13),
    axis.text.x = element_blank() # Remove labels under individual bars
  ) +
  ylim(0, 1) +
  facet_grid(~Task) +
  scale_fill_manual(values = colors)

# phonologyAllGG <- phonologyAllGG+ theme(legend.position = "none")
phonologyAllGG
ggsave("phonologyAllGG.pdf", height=3, width=4.25)



### ALL TASKS 

AllTasksGG <- ggarrange(
  ggarrange(recursionAllGG, movementAllGG, ncol = 2, widths = c(4.4, 2.225)),
  ggarrange(ambiguityAllGG, phonologyAllGG, ncol = 2, widths = c(2.3, 4)),
  nrow = 2,  ncol = 1, common.legend = TRUE, legend="bottom"
)

AllTasksGG

ggsave("AllTasksGG.pdf", height=6, width=9.6)
