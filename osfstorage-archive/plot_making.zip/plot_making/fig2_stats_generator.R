library(crayon)
library(RColorBrewer)
library(ggpubr)
library(wesanderson)
library(lme4)
library(emmeans)
library(effects)
library(xtable)



###AMBIGUITY

ambiguity_gpt_3_5_turbo_0125<-read.csv("_1_ambiguity_combined\ -\ gpt-3.5-turbo-0125.csv")
ambiguity_gpt_3_5_turbo_0125<-ambiguity_gpt_3_5_turbo_0125[-31,]
ambiguity_gpt_3_5_turbo_0125$Model<-"GPT-3.5"

ambiguity_gpt_4_0314<-read.csv("_1_ambiguity_combined\ -\ gpt-4-0314.csv")
ambiguity_gpt_4_0314<-ambiguity_gpt_4_0314[-31,]
ambiguity_gpt_4_0314$Model<-"GPT-4"

ambiguity_meta_llama3_1_405b_instruct_v1<-read.csv("_1_ambiguity_combined\ -\ meta.llama3-1-405b-instruct-v1.csv")
ambiguity_meta_llama3_1_405b_instruct_v1<-ambiguity_meta_llama3_1_405b_instruct_v1[-31,]
ambiguity_meta_llama3_1_405b_instruct_v1$Model<-"Llama 3.1"

ambiguity_o1_preview_2024_09_12<-read.csv("_1_ambiguity_combined\ -\ o1-preview-2024-09-12.csv")
ambiguity_o1_preview_2024_09_12<-ambiguity_o1_preview_2024_09_12[-31,]
ambiguity_o1_preview_2024_09_12$Model<-"O1 Preview"

ambiguity<-rbind(ambiguity_gpt_3_5_turbo_0125,ambiguity_gpt_4_0314,ambiguity_meta_llama3_1_405b_instruct_v1,ambiguity_o1_preview_2024_09_12)


ambiguityIdentAll<- data.frame(Score=ambiguity$ident.MAJ,Model=ambiguity$Model)

ambiguityIdentAll$Task<-"Identify"

ambiguityTreesAll<- data.frame(Score=ambiguity$trees.MAJ,Model=ambiguity$Model)

ambiguityTreesAll$Task<-"Tree"



ambiguityAll<-rbind(ambiguityIdentAll,ambiguityTreesAll)

ambiguityAll$Task<-factor(ambiguityAll$Task,levels=c("Identify","Tree"))

colors <- brewer.pal(9, "Blues")[c(4,5,6,7)]

ambiguityAllGG<-ggplot(ambiguityAll, aes(x = Model, y =  Score, fill=Model)) +
  stat_summary(fun = mean, geom = "bar",width = 1,
               position = position_dodge(width = 0)) +
  ylab("Score") +
  ggtitle("Ambiguity") +
  theme_minimal() +
  theme( strip.text = element_text(size = 14))+ylim(0,1)+
  facet_grid(~Task)+ scale_fill_manual(values = colors)
ambiguityAllGG



###RECURSION

recursion_gpt_3_5_turbo_0125<-read.csv("_2_recursion_combined\ -\ gpt-3.5-turbo-0125.csv")
recursion_gpt_3_5_turbo_0125<-recursion_gpt_3_5_turbo_0125[-31,]
recursion_gpt_3_5_turbo_0125$Model<-"GPT-3.5"

recursion_gpt_4_0314<-read.csv("_2_recursion_combined\ -\ gpt-4-0314.csv")
recursion_gpt_4_0314<-recursion_gpt_4_0314[-31,]
recursion_gpt_4_0314$Model<-"GPT-4"

recursion_meta_llama3_1_405b_instruct_v1<-read.csv("_2_recursion_combined\ -\ meta.llama3-1-405b-instruct-v1.csv")
recursion_meta_llama3_1_405b_instruct_v1<-recursion_meta_llama3_1_405b_instruct_v1[-31,]
recursion_meta_llama3_1_405b_instruct_v1$Model<-"Llama 3.1"

recursion_o1_preview_2024_09_12<-read.csv("_2_recursion_combined\ -\ o1-preview-2024-09-12.csv")
recursion_o1_preview_2024_09_12<-recursion_o1_preview_2024_09_12[-31,]
recursion_o1_preview_2024_09_12$Model<-"O1 Preview"

recursion<-rbind(recursion_gpt_3_5_turbo_0125,recursion_gpt_4_0314,recursion_meta_llama3_1_405b_instruct_v1,recursion_o1_preview_2024_09_12)





recursionIdentAll<- data.frame(Score=recursion$ident.MAJ,Model=recursion$Model)

recursionIdentAll$Task<-"Identify"


recursionTypeAll<- data.frame(Score=recursion$type.MAJ,Model=recursion$Model)

recursionTypeAll$Task<-"Type"


recursionTreeAll<- data.frame(Score=recursion$tree.MAJ,Model=recursion$Model)

recursionTreeAll$Task<-"Tree"


recursionAddAll<- data.frame(Score=recursion$add.MAJ,Model=recursion$Model)

recursionAddAll$Task<-"Add"


recursionAll<-rbind(recursionIdentAll,recursionTypeAll,recursionTreeAll,recursionAddAll)

recursionAll$Task<-factor(recursionAll$Task,levels=c("Identify","Type","Tree","Add"))

colors <- brewer.pal(9, "Blues")[c(4,5,6,7)]

recursionAllGG<-ggplot(recursionAll, aes(x = Model, y =  Score, fill=Model)) +
  stat_summary(fun = mean, geom = "bar",width = 1,
               position = position_dodge(width = 0)) +
  ylab("Score") +
  ggtitle("Recursion") +
  theme_minimal() +
  theme( strip.text = element_text(size = 14))+ylim(0,1)+
  facet_grid(~Task)+ scale_fill_manual(values = colors)
recursionAllGG

ggsave("recursionAllGG.pdf",height=9,width=14)



###MOVEMENT

movement_gpt_3_5_turbo_0125<-read.csv("_3_movement_combined\ -\ gpt-3.5-turbo-0125.csv")
movement_gpt_3_5_turbo_0125<-movement_gpt_3_5_turbo_0125[-31,]
movement_gpt_3_5_turbo_0125$Model<-"GPT-3.5"

movement_gpt_4_0314<-read.csv("_3_movement_combined\ -\ gpt-4-0314.csv")
movement_gpt_4_0314<-movement_gpt_4_0314[-31,]
movement_gpt_4_0314$Model<-"GPT-4"

movement_meta_llama3_1_405b_instruct_v1<-read.csv("_3_movement_combined\ -\ meta.llama3-1-405b-instruct-v1.csv")
movement_meta_llama3_1_405b_instruct_v1<-movement_meta_llama3_1_405b_instruct_v1[-31,]
movement_meta_llama3_1_405b_instruct_v1$Model<-"Llama 3.1"

movement_o1_preview_2024_09_12<-read.csv("_3_movement_combined\ -\ o1-preview-2024-09-12.csv")
movement_o1_preview_2024_09_12<-movement_o1_preview_2024_09_12[-31,]
movement_o1_preview_2024_09_12$Model<-"O1 Preview"

movement<-rbind(movement_gpt_3_5_turbo_0125,movement_gpt_4_0314,movement_meta_llama3_1_405b_instruct_v1,movement_o1_preview_2024_09_12)



movementTreesAll<- data.frame(Score=movement$MAJ,Model=movement$Model)

movementTreesAll$Task<-"Tree"



movementAll<-rbind(movementTreesAll)

movementAll$Task<-factor(movementAll$Task,levels=c("Identify","Tree"))

colors <- brewer.pal(9, "Blues")[c(4,5,6,7)]

movementAllGG<-ggplot(movementAll, aes(x = Model, y =  Score, fill=Model)) +
  stat_summary(fun = mean, geom = "bar",width = 1,
               position = position_dodge(width = 0)) +
  ylab("Score") +
  ggtitle("Movement") +
  theme_minimal() +
  theme( strip.text = element_text(size = 14))+ylim(0,1)+
  facet_grid(~Task)+ scale_fill_manual(values = colors)
movementAllGG
movementAllGG<-movementAllGG+ theme(legend.position = "none")
ambiguityAllGG<-ambiguityAllGG+ theme(legend.position = "none")

AllTaskSyntaxGG<-ggarrange(
  ggarrange(ambiguityAllGG,movementAllGG, ncol = 2, widths = c(4, 2)),  # First row with width ratio 2:1
  recursionAllGG,                                             # Second row with one plot
  ncol = 1, nrow = 2,common.legend = TRUE,legend="bottom"
)

AllTaskSyntaxGG



### PHONOLOGY

phonology_gpt_3_5_turbo_0125<-read.csv("_4_phonology_combined\ -\ gpt-3.5-turbo-0125.csv")
phonology_gpt_3_5_turbo_0125<-phonology_gpt_3_5_turbo_0125[-31,]
phonology_gpt_3_5_turbo_0125$Model<-"GPT-3.5"

phonology_gpt_4_0314<-read.csv("_4_phonology_combined\ -\ gpt-4-0314.csv")
phonology_gpt_4_0314<-phonology_gpt_4_0314[-31,]
phonology_gpt_4_0314$Model<-"GPT-4"

phonology_meta_llama3_1_405b_instruct_v1<-read.csv("_4_phonology_combined\ -\ meta.llama3-1-405b-instruct-v1.csv")
phonology_meta_llama3_1_405b_instruct_v1<-phonology_meta_llama3_1_405b_instruct_v1[-31,]
phonology_meta_llama3_1_405b_instruct_v1$Model<-"Llama 3.1"

phonology_o1_preview_2024_09_12<-read.csv("_4_phonology_combined\ -\ o1-preview-2024-09-12.csv")
phonology_o1_preview_2024_09_12<-phonology_o1_preview_2024_09_12[-31,]
phonology_o1_preview_2024_09_12$Model<-"O1 Preview"

phonology<-rbind(phonology_gpt_3_5_turbo_0125,phonology_gpt_4_0314,phonology_meta_llama3_1_405b_instruct_v1,phonology_o1_preview_2024_09_12)


### STATS

library(dplyr)
library(tidyr)


ambiguity_long <- ambiguity %>%
  # If you do not need ident.MAJ, drop it. Otherwise omit this select(-ident.MAJ).
  select(-ident.MAJ,-trees.MAJ) %>%
  pivot_longer(
    cols = c(starts_with("ident"), starts_with("trees")), 
    names_to = c("type", "annotator"),
    names_sep = "\\.",           # Split at the dot
    values_to = "outcome"
  ) %>%
  arrange(item, type, annotator)

print(ambiguity_long,n=1000)

ambiguity_long<-ambiguity_long[ambiguity_long$type=="trees",]

ambiguity_long$Model<-factor(ambiguity_long$Model)
contrasts(ambiguity_long$Model)<-contr.helmert(levels(ambiguity_long$Model))



# plot(allEffects(ambiguity_model),type="response")



ambiguity_model<-glmer(outcome~Model+(Model|item)+(Model|annotator),data=ambiguity_long,family="binomial",control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
ambiguity_model_sum<-summary(ambiguity_model)
ambiguity_model_sum
AIC(ambiguity_model)
plot(allEffects(ambiguity_model),type="response")



xtable(ambiguity_model_sum$coefficients,digits=c(1,3,2,2,4))

ambiguity_model_eff<-allEffects(ambiguity_model)
ambiguity_model_eff.df<-as.data.frame(ambiguity_model_eff$Model)
ambiguity_model_eff.df$type<-"tree"

colors <- brewer.pal(9, "Blues")[c(5,6,8,9)]


ambiguity_ggplot<-ggplot(ambiguity_model_eff.df,aes(x=Model, y=fit,color=Model))+geom_point(aes(shape=Model))+ geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) +#+ geom_line(group=1)
  theme_minimal()+ggtitle("ambiguity")+ylim(0,1)+ylab("% correct")+theme(
    strip.text = element_text(size = 13),
    axis.text.x = element_blank() # Remove labels under individual bars
  ) +scale_color_manual(values = colors)+xlab(NULL)+facet_grid(~type)


ambiguity_ggplot

ambiguity_emmeans<-emmeans(ambiguity_model, specs=pairwise ~ Model,adjust="tukey")

ambiguity_emmeans<-as.data.frame(ambiguity_emmeans$contrast)

xtable(ambiguity_emmeans[c(1,2,3,4,5,6)],digits=c(1,2,4,4,4,3,3))



recursion_long <- recursion %>%
  # If you do not need ident.MAJ, drop it. Otherwise omit this select(-ident.MAJ).
  select(-ident.MAJ,-tree.MAJ,-type.MAJ,-add.MAJ) %>%
  pivot_longer(
    cols = c(starts_with("ident"), starts_with("tree"), starts_with("type"), starts_with("add")), 
    names_to = c("type", "annotator"),
    names_sep = "\\.",           # Split at the dot
    values_to = "outcome"
  ) %>%
  arrange(item, type, annotator)

print(recursion_long,n=1500)

recursion_long<-recursion_long[recursion_long$type!="ident",]

recursion_long$Model<-factor(recursion_long$Model)
contrasts(recursion_long$Model)<-contr.helmert(levels(recursion_long$Model))



# contrasts(recursion_long_red$type)
# contrasts(recursion_long_red$Model)



recursion_model<-glmer(outcome~Model*type+(Model|item)+(Model|annotator),data=recursion_long,family="binomial",control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
recursion_model_sum<-summary(recursion_model)
recursion_model_sum
AIC(recursion_model)
plot(allEffects(recursion_model),type="response")


xtable(recursion_model_sum$coefficients,digits=c(1,3,2,2,4))

recursion_model_eff<-allEffects(recursion_model)
recursion_model_eff.df<-as.data.frame(recursion_model_eff$`Model:type`)


colors <- brewer.pal(9, "Purples")[c(5,6,8,9)]

recursion_model_eff.df$type<-factor(recursion_model_eff.df$type,levels=c("type","tree","add"))

recursion_ggplot<-ggplot(recursion_model_eff.df,aes(x=Model, y=fit,color=Model))+geom_point(aes(shape=Model))+ geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) +#+ geom_line(group=1)
  theme_minimal()+ggtitle("recursion")+ylim(0,1)+ylab("% correct")+theme(
    strip.text = element_text(size = 13),
    axis.text.x = element_blank() # Remove labels under individual bars
  ) +scale_color_manual(values = colors)+xlab(NULL)+facet_grid(~type)

recursion_ggplot

recursion_emmeans<-emmeans(recursion_model, specs=pairwise ~ Model|type,adjust="tukey")
recursion_emmeans

xtable(recursion_emmeans$contrasts)



movement_long <- movement %>%
  select(-MAJ) %>%
  pivot_longer(
    cols = c(Alex, Allegra, Kai),  # which columns to pivot
    names_to = "annotator",             # new column with annotator names
    values_to = "outcome"               # new column with 0/1 values
  ) %>%
  arrange(item, annotator)


print(movement_long,n=1500)

movement_long$Model<-factor(movement_long$Model)
contrasts(movement_long$Model)<-contr.helmert(levels(movement_long$Model))



movement_model<-glmer(outcome~Model+(1|item)+(Model|annotator),data=movement_long,family="binomial",control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e7)))
movement_model_sum<-summary(movement_model)
movement_model_sum
plot(allEffects(movement_model),type="response")

#install.packages("merTools")
#library(merTools)



xtable(movement_model_sum$coefficients,digits=c(1,3,2,2,4))

movement_model_eff<-allEffects(movement_model)
movement_model_eff.df<-as.data.frame(movement_model_eff$Model)


colors <- brewer.pal(9, "Reds")[c(5,6,8,9)]

movement_model_eff.df$type<-"tree"

movement_model_eff.df

colnames(movement_model_eff.df)[
  colnames(movement_model_eff.df) == "Model"
] <- "model"
movement_model_eff.df$model <- factor(
  movement_model_eff.df$model,
  levels = c("GPT-3.5", "GPT-4", "Llama 3.1", "O1 Preview"),
  labels = c("gpt-3.5", "gpt-4", "llama3-1", "o1-preview")
)

movement_ggplot<-ggplot(movement_model_eff.df,aes(x=model, y=fit,color=model))+geom_point(aes(shape=model))+ geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) +#+ geom_line(group=1)
  theme_minimal()+ggtitle("movement")+ylim(0,1)+ylab("% correct")+theme(
    strip.text = element_text(size = 13),
    axis.text.x = element_blank() # Remove labels under individual bars
  ) +scale_color_manual(values = colors)+xlab(NULL)+facet_grid(~type)

movement_ggplot

movement_emmeans<-emmeans(movement_model, specs=pairwise ~ Model,adjust="tukey")
movement_emmeans<-as.data.frame(movement_emmeans$contrast)



xtable(movement_emmeans[c(1,2,3,4,5,6)],digits=c(1,2,4,4,4,3,3))








phonology

phonology_long <- phonology %>%
  # If you do not need ident.MAJ, drop it. Otherwise omit this select(-ident.MAJ).
  select(-input.MAJ,-output.MAJ,-environ.MAJ) %>%
  pivot_longer(
    cols = c(starts_with("input"), starts_with("output"), starts_with("environ")), 
    names_to = c("type", "annotator"),
    names_sep = "\\.",           # Split at the dot
    values_to = "outcome"
  ) %>%
  arrange(item, type, annotator)

print(phonology_long,n=1500)

phonology_long$type<-factor(phonology_long$type)
contrasts(phonology_long$type)<-contr.sum(levels(phonology_long$type))

phonology_long$Model<-factor(phonology_long$Model)
contrasts(phonology_long$Model)<-contr.helmert(levels(phonology_long$Model))




phonology_model<-glmer(outcome~Model*type+(Model|item)+(Model|annotator),data=phonology_long,family="binomial",control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))

phonology_model_sum<-summary(phonology_model)
phonology_model_sum
plot(allEffects(phonology_model),type="response")
xtable(phonology_model_sum$coefficients,digits=c(1,3,2,2,4))

phonology_model_eff<-allEffects(phonology_model)
phonology_model_eff.df<-as.data.frame(phonology_model_eff$`Model:type`)
phonology_model_eff.df$type<-factor(phonology_model_eff.df$type, levels=c("input","output","environ"))

colnames(phonology_model_eff.df)[
  colnames(phonology_model_eff.df) == "Model"
] <- "model"
phonology_model_eff.df$model <- factor(
  phonology_model_eff.df$model,
  levels = c("GPT-3.5", "GPT-4", "Llama 3.1", "O1 Preview"),
  labels = c("gpt-3.5", "gpt-4", "llama3-1", "o1-preview")
)



colors <- brewer.pal(9, "Greens")[c(5,6,8,9)]
phonology_ggplot<-ggplot(phonology_model_eff.df,aes(x=model, y=fit,color=model))+geom_point(aes(shape=model))+ geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) +#+ geom_line(group=1)
  theme_minimal()+ facet_grid(~type)+ggtitle("phonology")+ylim(0,1)+ylab("% correct")+theme(
    strip.text = element_text(size = 13),
    axis.text.x = element_blank() # Remove labels under individual bars
  ) +scale_color_manual(values = colors)+xlab(NULL)



phonology_emmeans<-emmeans(phonology_model, specs=pairwise ~ Model|type,adjust="tukey")
phonology_emmeans

xtable(phonology_emmeans$contrasts)





ggarrange(
  ggarrange(recursion_ggplot+ rremove("legend"), movement_ggplot, ncol = 2, widths = c(3.4, 2)),
  ggarrange(ambiguity_ggplot+ rremove("legend"), phonology_ggplot, ncol = 2, widths = c(1.3,4)),
  nrow = 2,  ncol = 1, common.legend = TRUE, legend="bottom"
)

ggsave("AllTasksModels.pdf",height=6, width=9.6)



